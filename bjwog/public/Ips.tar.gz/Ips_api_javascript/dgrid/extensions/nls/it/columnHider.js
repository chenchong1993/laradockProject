//>>built
define("dgrid/extensions/nls/it/columnHider",{popupLabel:"Mostra o nascondi colonne"});