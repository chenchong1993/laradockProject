//>>built
define("dgrid/extensions/nls/nl/columnHider",{popupLabel:"Kolommen weergeven of verbergen"});