//>>built
define("dijit/form/nls/sr/ComboBox",{previousMessage:"Prethodne opcije",nextMessage:"Vi\u0161e opcija"});