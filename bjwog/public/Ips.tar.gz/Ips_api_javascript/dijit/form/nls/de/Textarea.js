//>>built
define("dijit/form/nls/de/Textarea",{iframeEditTitle:"Editierbereich",iframeFocusTitle:"Rahmen f\u00fcr Editierbereich"});