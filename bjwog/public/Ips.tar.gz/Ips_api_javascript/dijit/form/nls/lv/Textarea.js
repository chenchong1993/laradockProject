//>>built
define("dijit/form/nls/lv/Textarea",{iframeEditTitle:"laukuma redi\u0123\u0113\u0161ana",iframeFocusTitle:"laukuma r\u0101mja redi\u0123\u0113\u0161ana"});