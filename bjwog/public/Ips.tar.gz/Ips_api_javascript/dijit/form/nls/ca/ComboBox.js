//>>built
define("dijit/form/nls/ca/ComboBox",{previousMessage:"Opcions anteriors",nextMessage:"M\u00e9s opcions"});