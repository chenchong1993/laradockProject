//>>built
define("dgrid1/extensions/nls/it/columnHider",{popupLabel:"Mostra o nascondi colonne"});