//>>built
define("dgrid1/extensions/nls/nb/columnHider",{popupLabel:"Vis eller skjul kolonner"});