//>>built
define("dgrid1/extensions/nls/sl/columnHider",{popupTriggerLabel:"Poka\u017ei ali skrij stolpce",popupLabel:"Poka\u017ei ali skrij stolpce"});