//>>built
define("dgrid1/extensions/nls/de/columnHider",{popupLabel:"Spalten ein- oder ausblenden"});