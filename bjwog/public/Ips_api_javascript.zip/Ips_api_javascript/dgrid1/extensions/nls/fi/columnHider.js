//>>built
define("dgrid1/extensions/nls/fi/columnHider",{popupLabel:"N\u00e4yt\u00e4 tai piilota sarakkeet"});